package mark.utils.bean;

/**
 * 
 *@author Marcos Vasconcelos
 */
public class FormatterAdapter implements Formatter {
	public String format(Object obj) {
		return null;
	};

	public Object parse(String s) {
		return null;
	};

	public String getName() {
		return null;
	};
}