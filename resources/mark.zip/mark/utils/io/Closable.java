package mark.utils.io;

public interface Closable {
	public void close();
}
