package mark.utils.swing.scroll;

public interface ScrollEventListener {
	public void scrollPerformed(ScrollEvent event);
}
