package mark.utils.swing;

public interface ObjectSelectListener {
	public void notifyObjectSelected(SelectEvent selectevent);
}